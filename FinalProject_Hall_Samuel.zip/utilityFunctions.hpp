/**
* @author Samuel Hall
* @date 03/10/2018
* @brief Description: Utility Functions interface
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

int getInt(int, int);
#endif // FUNCTIONS_HPP